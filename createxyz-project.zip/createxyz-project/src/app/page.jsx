"use client";
import React from "react";

function MainComponent() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [activeView, setActiveView] = useState("login");
  const [darkMode, setDarkMode] = useState(false);
  const [loginData, setLoginData] = useState({ email: "", password: "" });
  const [courses, setCourses] = useState([
    {
      id: 1,
      name: "Matematyka",
      teacher: "Jan Kowalski",
      type: "Przedmiot ścisły",
      startDate: "2025-01-01",
      endDate: "2025-06-30",
      difficulty: "Średniozaawansowany",
      availableSpots: 15,
      progress: 45,
      rating: 4.5,
      icon: "calculator",
      color: "blue",
      image: "/math-course.jpg",
    },
    {
      id: 2,
      name: "Język Polski",
      teacher: "Anna Nowak",
      type: "Przedmiot humanistyczny",
      startDate: "2025-01-01",
      endDate: "2025-06-30",
      difficulty: "Podstawowy",
      availableSpots: 20,
      progress: 30,
      rating: 4.8,
      icon: "book",
      color: "red",
      image: "/polish-course.jpg",
    },
  ]);
  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setUserRole("student");
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-2xl font-roboto text-center mb-8">
            System E-learningowy
          </h1>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="w-full px-4 py-2 border rounded-lg"
                value={loginData.email}
                onChange={(e) =>
                  setLoginData({ ...loginData, email: e.target.value })
                }
              />
            </div>
            <div>
              <input
                type="password"
                name="password"
                placeholder="Hasło"
                className="w-full px-4 py-2 border rounded-lg"
                value={loginData.password}
                onChange={(e) =>
                  setLoginData({ ...loginData, password: e.target.value })
                }
              />
            </div>
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
              Zaloguj się
            </button>
          </form>
          <div className="mt-4 text-center">
            <button
              className="text-blue-600 hover:underline"
              onClick={() => setActiveView("register")}
            >
              Zarejestruj się jako uczeń
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <span className="text-xl font-roboto">E-learning</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-600 hover:text-gray-900">
                <i className="fas fa-bell"></i>
              </button>
              <button className="text-gray-600 hover:text-gray-900">
                <i className="fas fa-envelope"></i>
              </button>
              <button
                className="text-gray-600 hover:text-gray-900"
                onClick={() => setIsLoggedIn(false)}
              >
                <i className="fas fa-sign-out-alt"></i>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-2">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-roboto">Dostępne kursy</h2>
              <div className="flex space-x-4">
                <select className="px-4 py-2 rounded-lg border">
                  <option>Wszystkie kategorie</option>
                  <option>Przedmioty ścisłe</option>
                  <option>Przedmioty humanistyczne</option>
                </select>
                <button
                  onClick={() => setDarkMode(!darkMode)}
                  className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300"
                >
                  <i className={`fas fa-${darkMode ? "sun" : "moon"}`}></i>
                </button>
              </div>
            </div>
            <div className="space-y-6">
              {courses.map((course) => (
                <div
                  key={course.id}
                  className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
                  style={{ animation: "fadeIn 0.5s ease-in" }}
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-24 h-24 rounded-lg overflow-hidden">
                      <img
                        src={course.image}
                        alt={`Kurs ${course.name}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <i
                          className={`fas fa-${course.icon} text-${course.color}-500`}
                        ></i>
                        <h3 className="text-xl font-roboto">{course.name}</h3>
                        <span className="bg-gray-100 text-sm px-2 py-1 rounded">
                          {course.difficulty}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <p className="text-gray-600">
                          <i className="fas fa-user-tie mr-2"></i>
                          {course.teacher}
                        </p>
                        <p className="text-gray-600">
                          <i className="fas fa-users mr-2"></i>
                          Wolne miejsca: {course.availableSpots}
                        </p>
                        <p className="text-gray-600">
                          <i className="fas fa-calendar mr-2"></i>
                          {course.startDate}
                        </p>
                        <p className="text-gray-600">
                          <i className="fas fa-star mr-2 text-yellow-400"></i>
                          {course.rating}/5.0
                        </p>
                      </div>
                      <div className="mt-4">
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${course.progress}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-600">
                            Postęp: {course.progress}%
                          </span>
                          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Dołącz do kursu
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="bg-white p-6 rounded-xl shadow-lg mb-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-gray-200 overflow-hidden">
                  <img
                    src="/default-avatar.jpg"
                    alt="Zdjęcie profilowe"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h2 className="text-xl font-roboto">Panel użytkownika</h2>
                  <p className="text-gray-600">Student</p>
                </div>
              </div>
              <ul className="space-y-3">
                <li className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <i className="fas fa-book text-blue-600 w-6"></i>
                  <span>Moje kursy</span>
                  <span className="ml-auto bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    3
                  </span>
                </li>
                <li className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <i className="fas fa-tasks text-green-600 w-6"></i>
                  <span>Zadania</span>
                  <span className="ml-auto bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                    5
                  </span>
                </li>
                <li className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <i className="fas fa-calendar text-purple-600 w-6"></i>
                  <span>Kalendarz</span>
                </li>
                <li className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <i className="fas fa-comments text-orange-600 w-6"></i>
                  <span>Czat</span>
                  <span className="ml-auto bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full">
                    2
                  </span>
                </li>
                <li className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <i className="fas fa-trophy text-yellow-600 w-6"></i>
                  <span>Osiągnięcia</span>
                </li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h3 className="text-lg font-roboto mb-4">
                Nadchodzące wydarzenia
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-sm">
                  <i className="fas fa-clock text-blue-600"></i>
                  <div>
                    <p className="font-medium">Test z matematyki</p>
                    <p className="text-gray-600">Jutro, 15:00</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <i className="fas fa-book text-green-600"></i>
                  <div>
                    <p className="font-medium">Oddanie projektu</p>
                    <p className="text-gray-600">Za 3 dni</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;